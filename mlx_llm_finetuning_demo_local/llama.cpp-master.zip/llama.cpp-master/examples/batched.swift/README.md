This is a swift clone of `examples/batched`.

$ `make`
$ `./llama-batched-swift MODEL_PATH [PROMPT] [PARALLEL]`
